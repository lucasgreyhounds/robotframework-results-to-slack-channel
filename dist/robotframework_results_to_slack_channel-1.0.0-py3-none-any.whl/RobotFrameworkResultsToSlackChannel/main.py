def hello():
    print("Hello, Lucas!")